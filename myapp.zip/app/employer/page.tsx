import React from "react";

const Home = () => {
  return <div>Employer</div>;
};

export default Home;
