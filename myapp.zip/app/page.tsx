import React from "react";

const Home = () => {
  return <div>page</div>;
};

export default Home;
